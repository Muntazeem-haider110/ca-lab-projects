.text
.globl main
main:
    li x10, 0x78786464
    li x5, 0x100
    sw x10, 0(x5)
end:
    j end