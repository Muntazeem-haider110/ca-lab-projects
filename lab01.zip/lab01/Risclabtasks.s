.text
.globl main
main:
    li x5,0x1F0
    lhu x13,0(x5)
end:
    j end