.text
.globl main
main:
    li x20, 5 # a = 5         
    li x21, 0  # b = 0     
    addi x20, x21, 32 # a = 32
    add x22, x20, x21 # c = a + b = 32 + 0 = 32
    addi x23, x22, -5  # d= x23 = 32 + 0 - 5 = 27, x22 = d
   
    sub x5, x20,x23         
    sub x6, x21,x20
    add x19, x5, x6  
    add x7, x19, x23

    add x8,x20,x21
    add x8,x8,x23        # x7 = e
    add x7,x8,x7
end:
    j end