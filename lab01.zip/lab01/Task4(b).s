.text
.globl main
main:
        # Base addresses
    li t0, 0x100       # address of a
    li t1, 0x200       # address of b
    li t2, 0x300       # address of c

    # ---- i = 0 ----
    lb t3, 0(t0)       # load a[0] (byte)
    lh t4, 0(t1)       # load b[0] (halfword)
    add t5, t3, t4     # sum = a[0] + b[0]
    sw t5, 0(t2)       # store into c[0] (word)

    # ---- i = 1 ----
    lb t3, 1(t0)       # a[1]
    lh t4, 2(t1)       # b[1] (offset 2 bytes)
    add t5, t3, t4
    sw t5, 4(t2)       # c[1] (offset 4 bytes)

    # ---- i = 2 ----
    lb t3, 2(t0)       # a[2]
    lh t4, 4(t1)       # b[2]
    add t5, t3, t4
    sw t5, 8(t2)       # c[2]

    # ---- i = 3 ----
    lb t3, 3(t0)       # a[3]
    lh t4, 6(t1)       # b[3]
    add t5, t3, t4
    sw t5, 12(t2)      # c[3]

end:
    j end