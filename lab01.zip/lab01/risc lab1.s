.text
.globl main
main:
    li x11,0xA8A81919
    li x5, 0x1F0
    sw x11, 0(x5)
end:
    j end