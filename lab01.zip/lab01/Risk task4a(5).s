.text
.globl main
main:
    li x5, 0x1F0
    lh x13, 0(x5)
end:
    j end