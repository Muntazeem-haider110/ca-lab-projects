.text
.globl main
main:
    li x5, 0x1F0
    lb x14, 0(x5)
end:
    j end